# Vant Doc

UI components of Vant document site

#### NPM

```shell
npm i @vant/doc -D
```

#### YARN

```shell
yarn add @vant/doc --dev
```
