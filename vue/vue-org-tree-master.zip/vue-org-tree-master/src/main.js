import Vue2OrgTree from './components/org-tree'

export default Vue2OrgTree
